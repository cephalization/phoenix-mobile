import type { CodegenTypes as CT, ColorValue, HostComponent, ImageResolvedAssetSource, ViewProps } from 'react-native';
import { UnsafeMixed } from '../codegenUtils';
export type Placement = 'leading' | 'trailing' | 'toolbar' | 'title' | 'subtitle' | 'largeSubtitle';
export type Variant = 'plain' | 'prominent';
export type StackHeaderMenuItemIOS = {
    id: string;
    type: 'menuItem';
    title?: string | undefined;
    keepsMenuPresented?: boolean | undefined;
};
export type StackHeaderMenuIOS = {
    id: string;
    type: 'menu';
    title?: string | undefined;
    singleSelection?: boolean | undefined;
    icon?: object | undefined;
    displayInline?: boolean | undefined;
    displayAsPalette?: boolean | undefined;
    children: StackHeaderMenuElementIOS[];
};
export type StackHeaderMenuElementIOS = StackHeaderMenuItemIOS | StackHeaderMenuIOS;
export type HeaderItemPressEvent = Readonly<{}>;
export type PlatformIconShared = {
    type: 'imageSource';
    imageSource: ImageResolvedAssetSource;
};
export type PlatformIconIOSTemplate = {
    type: 'templateSource';
    templateSource: ImageResolvedAssetSource;
};
export type PlatformIconIOSSfSymbol = {
    type: 'sfSymbol';
    name: string;
};
export type PlatformIconIOSXcasset = {
    type: 'xcasset';
    name: string;
};
export type PlatformIconIOS = PlatformIconIOSSfSymbol | PlatformIconIOSXcasset | PlatformIconIOSTemplate | PlatformIconShared;
export type StackHeaderItemVisibilityPriorityIOS = 'low' | 'standard' | 'high';
export interface NativeProps extends ViewProps {
    placement?: CT.WithDefault<Placement, 'trailing'>;
    itemId?: string | undefined;
    identifier?: string | undefined;
    hidesSharedBackground?: CT.WithDefault<boolean, false>;
    searchBarPlacement?: CT.WithDefault<boolean, false>;
    axisBehavior?: CT.WithDefault<'automatic' | 'horizontalOnly' | 'verticalPreferred', 'automatic'>;
    visibilityPriority?: CT.WithDefault<StackHeaderItemVisibilityPriorityIOS, 'standard'>;
    variant?: CT.WithDefault<'plain' | 'done' | 'prominent', 'plain'>;
    tintColor?: ColorValue | undefined;
    title?: string | undefined;
    icon?: UnsafeMixed<PlatformIconIOS> | undefined;
    menu?: UnsafeMixed<StackHeaderMenuIOS> | undefined;
    menuRepresentation?: UnsafeMixed<StackHeaderMenuIOS> | undefined;
    disabled?: CT.WithDefault<boolean, false>;
    respondsToOnPress?: CT.WithDefault<boolean, false>;
    onHeaderItemPress?: CT.DirectEventHandler<HeaderItemPressEvent> | undefined;
}
declare const _default: HostComponent<NativeProps>;
export default _default;
//# sourceMappingURL=HeaderItemIOSNativeComponent.d.ts.map