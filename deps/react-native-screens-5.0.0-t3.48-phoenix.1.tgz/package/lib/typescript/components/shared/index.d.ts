import { type ImageResolvedAssetSource } from 'react-native';
import type { PlatformIconAndroid } from '../shared/types';
export declare function parseAndroidIconToNativeProps(icon: PlatformIconAndroid | undefined): {
    imageIconResource?: ImageResolvedAssetSource | undefined;
    drawableIconResourceName?: string | undefined;
};
//# sourceMappingURL=index.d.ts.map