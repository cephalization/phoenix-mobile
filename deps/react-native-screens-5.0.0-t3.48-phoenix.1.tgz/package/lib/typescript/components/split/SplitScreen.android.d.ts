declare const _default: {
    Column: () => null;
    Stack: () => null;
    Screen: () => null;
    Inspector: () => null;
};
export default _default;
//# sourceMappingURL=SplitScreen.android.d.ts.map