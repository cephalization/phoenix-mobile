'use client';

import type {
  ColorValue,
  CodegenTypes as CT,
  HostComponent,
  ImageSource,
  ProcessedColorValue,
  ViewProps,
} from 'react-native';
import { codegenNativeCommands, codegenNativeComponent } from 'react-native';
import type { UnsafeMixed } from '../codegenUtils';

type StackHeaderTypeAndroid = 'small' | 'medium' | 'large';

type StackHeaderTitleHorizontalGravityAndroid = 'start' | 'center' | 'end';

type StackHeaderTitleVerticalGravityAndroid = 'top' | 'center' | 'bottom';

type StackHeaderCollapsedTitleGravityModeAndroid =
  | 'entireSpace'
  | 'availableSpace';

export type StackHeaderToolbarMenuItemPressEventAndroid = Readonly<{
  id: string;
}>;

export type StackHeaderToolbarMenuGroupSelectionChangeEventAndroid = Readonly<{
  groupId: string;
  selectedIds: string[];
}>;

type StackHeaderToolbarMenuItemShowAsActionAndroid =
  | 'always'
  | 'alwaysWithText'
  | 'ifRoom'
  | 'ifRoomWithText'
  | 'never';

type StackHeaderToolbarMenuItemTypeAndroid = 'action' | 'toggle' | 'automatic';

export interface StackHeaderToolbarMenuItemBaseAndroid {
  id: string;
  title?: string | undefined;
  titleCondensed?: string | undefined;
  tooltipText?: string | undefined;
  accessibilityLabel?: string | undefined;
  hidden?: CT.WithDefault<boolean, false>;
  disabled?: CT.WithDefault<boolean, false>;
  showAsAction?: CT.WithDefault<
    StackHeaderToolbarMenuItemShowAsActionAndroid,
    'never'
  >;
  drawableIconResourceName?: string | null | undefined;
  imageIconResource?: ImageSource | null | undefined;
  iconTintColorNormal?: ProcessedColorValue | null | undefined;
  iconTintColorPressed?: ProcessedColorValue | null | undefined;
  iconTintColorFocused?: ProcessedColorValue | null | undefined;
  iconTintColorDisabled?: ProcessedColorValue | null | undefined;
}

type StackHeaderToolbarMenuItemAndroid =
  StackHeaderToolbarMenuItemBaseAndroid & {
    type: 'menuItem';
    groupId?: string | undefined;
    itemType?: CT.WithDefault<
      StackHeaderToolbarMenuItemTypeAndroid,
      'automatic'
    >;
    initialToggleState?: CT.WithDefault<boolean, false>;
  };

type StackHeaderToolbarMenuGroupAndroid = {
  groupId: string;
  singleSelection?: CT.WithDefault<boolean, false>;
};

export type StackHeaderToolbarMenuBaseAndroid = {
  groups?: StackHeaderToolbarMenuGroupAndroid[] | undefined;
  children?: StackHeaderToolbarMenuElementAndroid[] | undefined;
};

type StackHeaderToolbarMenuAndroid = StackHeaderToolbarMenuItemBaseAndroid &
  StackHeaderToolbarMenuBaseAndroid & {
    type: 'menu';
    menuTitle?: string | undefined;
  };

export type StackHeaderToolbarMenuElementAndroid =
  | StackHeaderToolbarMenuItemAndroid
  | StackHeaderToolbarMenuAndroid;

export interface NativeProps extends ViewProps {
  title?: string | undefined;
  subtitle?: string | undefined;
  maxLines?: CT.WithDefault<CT.Int32, 1>;
  hidden?: CT.WithDefault<boolean, false>;
  transparent?: CT.WithDefault<boolean, false>;
  backButtonHidden?: CT.WithDefault<boolean, false>;

  // Android-specific props
  type?: CT.WithDefault<StackHeaderTypeAndroid, 'small'>;

  titleCentered?: CT.WithDefault<boolean, false>;
  subtitleCentered?: CT.WithDefault<boolean, false>;

  expandedTitleHorizontalGravity?: CT.WithDefault<
    StackHeaderTitleHorizontalGravityAndroid,
    'start'
  >;
  expandedTitleVerticalGravity?: CT.WithDefault<
    StackHeaderTitleVerticalGravityAndroid,
    'bottom'
  >;
  collapsedTitleHorizontalGravity?: CT.WithDefault<
    StackHeaderTitleHorizontalGravityAndroid,
    'start'
  >;
  collapsedTitleVerticalGravity?: CT.WithDefault<
    StackHeaderTitleVerticalGravityAndroid,
    'center'
  >;
  collapsedTitleGravityMode?: CT.WithDefault<
    StackHeaderCollapsedTitleGravityModeAndroid,
    'availableSpace'
  >;

  contentInsetStart?: CT.WithDefault<CT.Float, -1.0>;
  contentInsetEnd?: CT.WithDefault<CT.Float, -1.0>;

  titleColor?: ColorValue | undefined;
  titleFontFamily?: string | undefined;
  titleFontSize?: CT.WithDefault<CT.Float, -1.0>;
  titleFontWeight?: string | undefined;
  titleFontStyle?: string | undefined;
  subtitleColor?: ColorValue | undefined;
  subtitleFontFamily?: string | undefined;
  subtitleFontSize?: CT.WithDefault<CT.Float, -1.0>;
  subtitleFontWeight?: string | undefined;
  subtitleFontStyle?: string | undefined;
  expandedTitleColor?: ColorValue | undefined;
  expandedTitleFontFamily?: string | undefined;
  expandedTitleFontSize?: CT.WithDefault<CT.Float, -1.0>;
  expandedTitleFontWeight?: string | undefined;
  expandedTitleFontStyle?: string | undefined;
  collapsedTitleColor?: ColorValue | undefined;
  collapsedTitleFontFamily?: string | undefined;
  collapsedTitleFontSize?: CT.WithDefault<CT.Float, -1.0>;
  collapsedTitleFontWeight?: string | undefined;
  collapsedTitleFontStyle?: string | undefined;
  expandedSubtitleColor?: ColorValue | undefined;
  expandedSubtitleFontFamily?: string | undefined;
  expandedSubtitleFontSize?: CT.WithDefault<CT.Float, -1.0>;
  expandedSubtitleFontWeight?: string | undefined;
  expandedSubtitleFontStyle?: string | undefined;
  collapsedSubtitleColor?: ColorValue | undefined;
  collapsedSubtitleFontFamily?: string | undefined;
  collapsedSubtitleFontSize?: CT.WithDefault<CT.Float, -1.0>;
  collapsedSubtitleFontWeight?: string | undefined;
  collapsedSubtitleFontStyle?: string | undefined;

  backButtonTintColorNormal?: ColorValue | undefined;
  backButtonTintColorPressed?: ColorValue | undefined;
  backButtonTintColorFocused?: ColorValue | undefined;
  backButtonDrawableIconResourceName?: string | undefined;
  backButtonImageIconResource?: ImageSource | undefined;

  overflowIconTintColorNormal?: ColorValue | undefined;
  overflowIconTintColorPressed?: ColorValue | undefined;
  overflowIconTintColorFocused?: ColorValue | undefined;
  overflowIconDrawableIconResourceName?: string | undefined;
  overflowIconImageIconResource?: ImageSource | undefined;

  scrollFlagScroll?: CT.WithDefault<boolean, false>;
  scrollFlagEnterAlways?: CT.WithDefault<boolean, false>;
  scrollFlagEnterAlwaysCollapsed?: CT.WithDefault<boolean, false>;
  scrollFlagExitUntilCollapsed?: CT.WithDefault<boolean, false>;
  scrollFlagSnap?: CT.WithDefault<boolean, false>;

  liftOnScroll?: CT.WithDefault<boolean, true>;

  backgroundColor?: ColorValue | undefined;
  scrolledBackgroundColor?: ColorValue | undefined;
  statusBarScrimColor?: ColorValue | undefined;

  toolbarMenu?: UnsafeMixed<StackHeaderToolbarMenuBaseAndroid> | undefined;
  toolbarMenuGroupDividerEnabled?: CT.WithDefault<boolean, false>;
  onToolbarMenuItemPress?:
    | CT.DirectEventHandler<StackHeaderToolbarMenuItemPressEventAndroid>
    | undefined;
  onToolbarMenuGroupSelectionChange?:
    | CT.DirectEventHandler<StackHeaderToolbarMenuGroupSelectionChangeEventAndroid>
    | undefined;
}

type ComponentType = HostComponent<NativeProps>;

export type StackHeaderToolbarMenuElementOptionsAndroid = Partial<
  Omit<StackHeaderToolbarMenuItemBaseAndroid, 'id'>
> & {
  checked?: boolean | undefined;
  menuTitle?: string | undefined;
};

type StackHeaderToolbarMenuElementUpdateNativeAndroid =
  StackHeaderToolbarMenuElementOptionsAndroid & { id: string };

export interface NativeCommands {
  updateToolbarMenuElements: (
    viewRef: React.ComponentRef<ComponentType>,
    updates: StackHeaderToolbarMenuElementUpdateNativeAndroid[],
  ) => void;
}

export const Commands: NativeCommands = codegenNativeCommands<NativeCommands>({
  supportedCommands: ['updateToolbarMenuElements'],
});

export default codegenNativeComponent<NativeProps>(
  'RNSStackHeaderConfigAndroid',
  {
    interfaceOnly: true,
    excludedPlatforms: ['iOS'],
  },
) as HostComponent<NativeProps>;
